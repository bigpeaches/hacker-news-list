/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/components/HackerNewsCard/index.tsx":
/*!*************************************************!*\
  !*** ./src/components/HackerNewsCard/index.tsx ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {



;
    // Wrapped in an IIFE to avoid polluting the global scope
    ;
    (function () {
        var _a, _b;
        // Legacy CSS implementations will `eval` browser code in a Node.js context
        // to extract CSS. For backwards compatibility, we need to check we're in a
        // browser context before continuing.
        if (typeof self !== 'undefined' &&
            // AMP / No-JS mode does not inject these helpers:
            '$RefreshHelpers$' in self) {
            // @ts-ignore __webpack_module__ is global
            var currentExports = module.exports;
            // @ts-ignore __webpack_module__ is global
            var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
            // This cannot happen in MainTemplate because the exports mismatch between
            // templating and execution.
            self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
            // A module can be accepted automatically based on its exports, e.g. when
            // it is a Refresh Boundary.
            if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
                // Save the previous exports on update so we can compare the boundary
                // signatures.
                module.hot.dispose(function (data) {
                    data.prevExports = currentExports;
                });
                // Unconditionally accept an update to this module, we'll check if it's
                // still a Refresh Boundary later.
                // @ts-ignore importMeta is replaced in the loader
                module.hot.accept();
                // This field is set when the previous version of this module was a
                // Refresh Boundary, letting us know we need to check for invalidation or
                // enqueue an update.
                if (prevExports !== null) {
                    // A boundary can become ineligible if its exports are incompatible
                    // with the previous exports.
                    //
                    // For example, if you add/remove/change exports, we'll want to
                    // re-execute the importing modules, and force those components to
                    // re-render. Similarly, if you convert a class component to a
                    // function, we want to invalidate the boundary.
                    if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                        module.hot.invalidate();
                    }
                    else {
                        self.$RefreshHelpers$.scheduleUpdate();
                    }
                }
            }
            else {
                // Since we just executed the code for the module, it's possible that the
                // new exports made it ineligible for being a boundary.
                // We only care about the case when we were _previously_ a boundary,
                // because we already accepted this update (accidental side effect).
                var isNoLongerABoundary = prevExports !== null;
                if (isNoLongerABoundary) {
                    module.hot.invalidate();
                }
            }
        }
    })();


/***/ }),

/***/ "./src/components/HackerNewsList/index.tsx":
/*!*************************************************!*\
  !*** ./src/components/HackerNewsList/index.tsx ***!
  \*************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval(__webpack_require__.ts("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"./node_modules/react/jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"./node_modules/react/index.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _HackerNewsCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../HackerNewsCard */ \"./src/components/HackerNewsCard/index.tsx\");\n/* harmony import */ var _HackerNewsCard__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_HackerNewsCard__WEBPACK_IMPORTED_MODULE_2__);\n\nvar _s = $RefreshSig$();\n\n\nconst HackerNewsList = (param)=>{\n    let { newslist  } = param;\n    _s();\n    const pageSize = 12;\n    const [page, setPage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);\n    const paginatedList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{\n        return newslist.slice(0, page * pageSize);\n    }, [\n        page,\n        newslist\n    ]);\n    const handleLoadMore = ()=>{\n        if (page < newslist.length / pageSize) {\n            setPage(page + 1);\n        }\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"mt-5\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-2 gap-4\",\n                children: paginatedList === null || paginatedList === void 0 ? void 0 : paginatedList.map((item)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_HackerNewsCard__WEBPACK_IMPORTED_MODULE_2___default()), {\n                        item: item\n                    }, item.id, false, {\n                        fileName: \"/home/dev/Documents/hacker-news-list/src/components/HackerNewsList/index.tsx\",\n                        lineNumber: 26,\n                        columnNumber: 11\n                    }, undefined))\n            }, void 0, false, {\n                fileName: \"/home/dev/Documents/hacker-news-list/src/components/HackerNewsList/index.tsx\",\n                lineNumber: 24,\n                columnNumber: 7\n            }, undefined),\n            page < newslist.length / pageSize && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"flex\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    type: \"button\",\n                    className: \"px-4 py-3 bg-blue-600 text-white mx-auto mt-5 rounded-lg hover:opacity-80 active:opacity-100\",\n                    onClick: ()=>handleLoadMore(),\n                    children: \"Load More\"\n                }, void 0, false, {\n                    fileName: \"/home/dev/Documents/hacker-news-list/src/components/HackerNewsList/index.tsx\",\n                    lineNumber: 31,\n                    columnNumber: 11\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"/home/dev/Documents/hacker-news-list/src/components/HackerNewsList/index.tsx\",\n                lineNumber: 30,\n                columnNumber: 9\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"/home/dev/Documents/hacker-news-list/src/components/HackerNewsList/index.tsx\",\n        lineNumber: 23,\n        columnNumber: 5\n    }, undefined);\n};\n_s(HackerNewsList, \"+5ltI0WmlYyB5qYGNTOyFJvm+m0=\");\n_c = HackerNewsList;\n/* harmony default export */ __webpack_exports__[\"default\"] = (HackerNewsList);\nvar _c;\n$RefreshReg$(_c, \"HackerNewsList\");\n\n\n;\n    // Wrapped in an IIFE to avoid polluting the global scope\n    ;\n    (function () {\n        var _a, _b;\n        // Legacy CSS implementations will `eval` browser code in a Node.js context\n        // to extract CSS. For backwards compatibility, we need to check we're in a\n        // browser context before continuing.\n        if (typeof self !== 'undefined' &&\n            // AMP / No-JS mode does not inject these helpers:\n            '$RefreshHelpers$' in self) {\n            // @ts-ignore __webpack_module__ is global\n            var currentExports = module.exports;\n            // @ts-ignore __webpack_module__ is global\n            var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;\n            // This cannot happen in MainTemplate because the exports mismatch between\n            // templating and execution.\n            self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);\n            // A module can be accepted automatically based on its exports, e.g. when\n            // it is a Refresh Boundary.\n            if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {\n                // Save the previous exports on update so we can compare the boundary\n                // signatures.\n                module.hot.dispose(function (data) {\n                    data.prevExports = currentExports;\n                });\n                // Unconditionally accept an update to this module, we'll check if it's\n                // still a Refresh Boundary later.\n                // @ts-ignore importMeta is replaced in the loader\n                module.hot.accept();\n                // This field is set when the previous version of this module was a\n                // Refresh Boundary, letting us know we need to check for invalidation or\n                // enqueue an update.\n                if (prevExports !== null) {\n                    // A boundary can become ineligible if its exports are incompatible\n                    // with the previous exports.\n                    //\n                    // For example, if you add/remove/change exports, we'll want to\n                    // re-execute the importing modules, and force those components to\n                    // re-render. Similarly, if you convert a class component to a\n                    // function, we want to invalidate the boundary.\n                    if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {\n                        module.hot.invalidate();\n                    }\n                    else {\n                        self.$RefreshHelpers$.scheduleUpdate();\n                    }\n                }\n            }\n            else {\n                // Since we just executed the code for the module, it's possible that the\n                // new exports made it ineligible for being a boundary.\n                // We only care about the case when we were _previously_ a boundary,\n                // because we already accepted this update (accidental side effect).\n                var isNoLongerABoundary = prevExports !== null;\n                if (isNoLongerABoundary) {\n                    module.hot.invalidate();\n                }\n            }\n        }\n    })();\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9IYWNrZXJOZXdzTGlzdC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQzBDO0FBQ0s7QUFNL0MsTUFBTUcsaUJBQWlCLFNBQXVDO1FBQXRDLEVBQUVDLFNBQVEsRUFBdUI7O0lBQ3ZELE1BQU1DLFdBQVc7SUFDakIsTUFBTSxDQUFDQyxNQUFNQyxRQUFRLEdBQUdOLCtDQUFRQSxDQUFDO0lBQ2pDLE1BQU1PLGdCQUFnQlIsOENBQU9BLENBQUMsSUFBTTtRQUNsQyxPQUFPSSxTQUFTSyxLQUFLLENBQUMsR0FBR0gsT0FBT0Q7SUFDbEMsR0FBRztRQUFDQztRQUFNRjtLQUFTO0lBRW5CLE1BQU1NLGlCQUFpQixJQUFNO1FBQzNCLElBQUlKLE9BQU9GLFNBQVNPLE1BQU0sR0FBR04sVUFBVTtZQUNyQ0UsUUFBUUQsT0FBTztRQUNqQixDQUFDO0lBQ0g7SUFFQSxxQkFDRSw4REFBQ007UUFBSUMsV0FBVTs7MEJBQ2IsOERBQUNEO2dCQUFJQyxXQUFVOzBCQUNaTCwwQkFBQUEsMkJBQUFBLEtBQUFBLElBQUFBLGNBQWVNLEdBQUcsQ0FBQyxDQUFDQyxxQkFDbkIsOERBQUNiLHdEQUFjQTt3QkFBQ2EsTUFBTUE7dUJBQVdBLEtBQUtDLEVBQUU7Ozs7Ozs7Ozs7WUFHM0NWLE9BQU9GLFNBQVNPLE1BQU0sR0FBR04sMEJBQ3hCLDhEQUFDTztnQkFBSUMsV0FBVTswQkFDYiw0RUFBQ0k7b0JBQ0NDLE1BQUs7b0JBQ0xMLFdBQVU7b0JBQ1ZNLFNBQVMsSUFBTVQ7OEJBQ2hCOzs7Ozs7Ozs7Ozs7Ozs7OztBQU9YO0dBakNNUDtLQUFBQTtBQW1DTiwrREFBZUEsY0FBY0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9zcmMvY29tcG9uZW50cy9IYWNrZXJOZXdzTGlzdC9pbmRleC50c3g/M2U3MyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIYWNrZXJOZXdzSXRlbSB9IGZyb20gXCJAL2NvbnN0YW50cy90eXBlc1wiO1xyXG5pbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgSGFja2VyTmV3c0NhcmQgZnJvbSBcIi4uL0hhY2tlck5ld3NDYXJkXCI7XHJcblxyXG50eXBlIEhhY2tlck5ld3NMaXN0UHJvcHMgPSB7XHJcbiAgbmV3c2xpc3Q6IEhhY2tlck5ld3NJdGVtW107XHJcbn07XHJcblxyXG5jb25zdCBIYWNrZXJOZXdzTGlzdCA9ICh7IG5ld3NsaXN0IH06IEhhY2tlck5ld3NMaXN0UHJvcHMpID0+IHtcclxuICBjb25zdCBwYWdlU2l6ZSA9IDEyO1xyXG4gIGNvbnN0IFtwYWdlLCBzZXRQYWdlXSA9IHVzZVN0YXRlKDEpO1xyXG4gIGNvbnN0IHBhZ2luYXRlZExpc3QgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBuZXdzbGlzdC5zbGljZSgwLCBwYWdlICogcGFnZVNpemUpO1xyXG4gIH0sIFtwYWdlLCBuZXdzbGlzdF0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVMb2FkTW9yZSA9ICgpID0+IHtcclxuICAgIGlmIChwYWdlIDwgbmV3c2xpc3QubGVuZ3RoIC8gcGFnZVNpemUpIHtcclxuICAgICAgc2V0UGFnZShwYWdlICsgMSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgeGw6Z3JpZC1jb2xzLTQgbGc6Z3JpZC1jb2xzLTMgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICB7cGFnaW5hdGVkTGlzdD8ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICA8SGFja2VyTmV3c0NhcmQgaXRlbT17aXRlbX0ga2V5PXtpdGVtLmlkfSAvPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge3BhZ2UgPCBuZXdzbGlzdC5sZW5ndGggLyBwYWdlU2l6ZSAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTMgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBteC1hdXRvIG10LTUgcm91bmRlZC1sZyBob3ZlcjpvcGFjaXR5LTgwIGFjdGl2ZTpvcGFjaXR5LTEwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUxvYWRNb3JlKCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIExvYWQgTW9yZVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGFja2VyTmV3c0xpc3Q7XHJcbiJdLCJuYW1lcyI6WyJ1c2VNZW1vIiwidXNlU3RhdGUiLCJIYWNrZXJOZXdzQ2FyZCIsIkhhY2tlck5ld3NMaXN0IiwibmV3c2xpc3QiLCJwYWdlU2l6ZSIsInBhZ2UiLCJzZXRQYWdlIiwicGFnaW5hdGVkTGlzdCIsInNsaWNlIiwiaGFuZGxlTG9hZE1vcmUiLCJsZW5ndGgiLCJkaXYiLCJjbGFzc05hbWUiLCJtYXAiLCJpdGVtIiwiaWQiLCJidXR0b24iLCJ0eXBlIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/HackerNewsList/index.tsx\n"));

/***/ })

});